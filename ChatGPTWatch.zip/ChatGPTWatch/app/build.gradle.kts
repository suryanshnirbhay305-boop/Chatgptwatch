plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android {
 namespace = "com.suryansh.chatgptwatch"; compileSdk = 35
 defaultConfig { applicationId = "com.suryansh.chatgptwatch"; minSdk = 30; targetSdk = 35; versionCode = 2; versionName = "2.0" }
 buildFeatures { compose = true }
}
dependencies {
 implementation("androidx.activity:activity-compose:1.10.0")
 implementation("androidx.wear.compose:compose-material3:1.0.0-alpha32")
 implementation("androidx.wear.compose:compose-foundation:1.4.1")
 implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
