package com.suryansh.chatgptwatch

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.wear.compose.material3.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONObject

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App(this) } }
}

@Composable fun App(activity: Activity) {
 val prefs = remember { activity.getSharedPreferences("aiwatch", 0) }
 var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
 var prompt by remember { mutableStateOf("") }
 var answer by remember { mutableStateOf("Enter your API key once, then ask anything.") }
 var busy by remember { mutableStateOf(false) }
 val scope = rememberCoroutineScope()
 MaterialTheme {
  ScreenScaffold { padding ->
   Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 10.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
    Text("AI Watch", style = MaterialTheme.typography.titleMedium)
    TextField(value=key, onValueChange={ key=it }, label={Text("OpenAI API key")}, modifier=Modifier.fillMaxWidth())
    Button(onClick={ prefs.edit().putString("key", key.trim()).apply(); answer="Key saved on this watch." }, modifier=Modifier.fillMaxWidth()) { Text("Save key") }
    TextField(value=prompt, onValueChange={prompt=it}, label={Text("Ask")}, modifier=Modifier.fillMaxWidth())
    Button(enabled=!busy && prompt.isNotBlank() && key.isNotBlank(), onClick={ scope.launch { busy=true; answer="Thinking…"; answer=ask(key.trim(), prompt); busy=false } }, modifier=Modifier.fillMaxWidth()) { Text(if(busy) "Thinking…" else "Send") }
    Text(answer)
   }
  }
 }
}

suspend fun ask(key:String, text:String):String = withContext(Dispatchers.IO) {
 try {
  val json=JSONObject().put("model","gpt-5.6-luna").put("input",text)
  val req=Request.Builder().url("https://api.openai.com/v1/responses").header("Authorization","Bearer $key").header("Content-Type","application/json").post(json.toString().toRequestBody("application/json".toMediaType())).build()
  OkHttpClient().newCall(req).execute().use { r ->
   val body=r.body?.string().orEmpty(); if(!r.isSuccessful) return@withContext "Error ${r.code}: ${JSONObject(body).optJSONObject("error")?.optString("message") ?: body.take(180)}"
   val root=JSONObject(body); val out=root.optJSONArray("output") ?: return@withContext "No response text."
   for(i in 0 until out.length()) { val c=out.getJSONObject(i).optJSONArray("content") ?: continue; for(j in 0 until c.length()) { val t=c.getJSONObject(j).optString("text"); if(t.isNotBlank()) return@withContext t } }
   "No response text."
  }
 } catch(e:Exception) { "Error: ${e.message}" }
}
